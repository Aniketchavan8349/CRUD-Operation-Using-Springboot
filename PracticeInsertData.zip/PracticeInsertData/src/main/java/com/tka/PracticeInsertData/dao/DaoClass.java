package com.tka.PracticeInsertData.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tka.PracticeInsertData.entity.Employee1;

@Repository
public class DaoClass {
	
	@Autowired
	SessionFactory factory;
	
	public String insertData(Employee1 e) {
		
		
		Session session=factory.openSession();
		session.beginTransaction();
		session.persist(e);
		session.getTransaction().commit();
		session.close();
		
	
		return"Record is inserted..";
	}
	
	public String updateData(int id,Employee1 e) {
		Session session=factory.openSession();
		session.beginTransaction();
		
		Employee1 emp= session.get(Employee1.class,id);
		emp.setName(e.getName());
		emp.setEmail(e.getEmail());
		emp.setMobileno(e.getMobileno());
		
		session.merge(emp);
		session.getTransaction().commit();
		session.close();
		
		return"record is updated...";
		
		
	}
	
public String deleteData(int id) {
		
		
		Session session=factory.openSession();
		session.beginTransaction();
		Employee1 emp= session.get(Employee1.class, id);
		session.remove(emp);
		session.getTransaction().commit();
		session.close();
		
	
		return"Record is deleted..";
	}
	
		public Employee1 getPerticularRecord(int id) {

			Session session=factory.openSession();
			session.beginTransaction();
			
			String hqlQuery="from Employee1 where id=:myid";
			Query<Employee1> query= session.createQuery(hqlQuery,Employee1.class);
			query.setParameter("myid",id);
			Employee1 e= query.uniqueResult();
			session.getTransaction().commit();
			session.close();
			
			
			return e;
			
			
       }
		public List<Employee1> getAllRecord() {

			Session session=factory.openSession();
			session.beginTransaction();
			
			String hqlQuery="from Employee1";
			Query<Employee1> query= session.createQuery(hqlQuery,Employee1.class);
			List<Employee1> list= query.list();
			
			session.getTransaction().commit();
			session.close();
			
			return list;
       }
}
