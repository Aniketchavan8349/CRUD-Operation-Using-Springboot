package com.tka.PracticeInsertData.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.PracticeInsertData.dao.AddressDao;
import com.tka.PracticeInsertData.entity.AddressClass;

@Service
public class AddressService {
	
	@Autowired
	AddressDao dao;
	
	
	public String InsertData(AddressClass add) {
		
		String s=dao.insertData(add);
		return s;
	}

	public String UpdateData(int id,AddressClass add) {
			
			String s=dao.updateData(id,add);
			return s;
		}
	
	
	public String DeleteData(int id) {
		
		String s=dao.deleteData(id);
		return s;
	}
	public AddressClass getPerticularRecord(int id) {
		
		AddressClass s=dao.getPerticularRecordData(id);
		return s;
    }
	
	public List<AddressClass> getAllRecord(){
		List<AddressClass> list= dao.getAllRecord();
		return list;
	}
}
