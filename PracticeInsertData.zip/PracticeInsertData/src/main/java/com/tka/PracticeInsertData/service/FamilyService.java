package com.tka.PracticeInsertData.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.PracticeInsertData.dao.FamilyDao;
import com.tka.PracticeInsertData.entity.Family;

@Service
public class FamilyService {
	
	@Autowired
	FamilyDao dao;
	
	public String InsertData(Family f) {
		String s=dao.insertData(f);
		return s;
		
	}
	public String UpdateData(int id,Family f) {
		
		String s=dao.updateData(id, f);
		return s;
	}
	public String DeleteData(int id) {
		
		String st=dao.deleteData(id);
		return st;
	}
	public Family getAllRecord(int id) {
		
    	Family s=dao.getPerticularRecord(id);
		return s;
	}
	public List<Family> getAllRecord(){
		List<Family> list=dao.getAllRecord();
		return list;
	}

}
