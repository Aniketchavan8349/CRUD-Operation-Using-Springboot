package com.tka.PracticeInsertData.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.PracticeInsertData.dao.CountryDao;
import com.tka.PracticeInsertData.entity.CountryClass;

@Service
public class CountryService {
	
	@Autowired
	CountryDao dao;
	
	public String InsertData(CountryClass c) {
		String msg=dao.insertData(c);
		return msg;
	}
	
	
	public String UpdateData( int id,CountryClass c) {
		String msg=dao.insertData(c);
		return msg;
	}
	
	
	public String DeleteData(int id) {
		String msg=dao.deleteData(id);
		return msg;
   }
	
	
	public CountryClass getPerticularRecord(int id) {			
		CountryClass msg=dao.getPerticularRecord(id);
		return msg;
	}
	
	public List<CountryClass> getAllRecord( ) {			
		List<CountryClass> msg=dao.getAllRecord();
		return msg;
	}

	
}
