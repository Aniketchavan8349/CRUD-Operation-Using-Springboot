package com.tka.PracticeInsertData.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.amqp.RabbitConnectionDetails.Address;
import org.springframework.stereotype.Repository;

import com.tka.PracticeInsertData.entity.AddressClass;

@Repository
public class AddressDao {

	
	@Autowired
	SessionFactory factory;
	
	
	public String insertData(AddressClass add) {
		
		Session session=factory.openSession();
		session.beginTransaction();
		session.persist(add);
		session.getTransaction().commit();
		session.close();
		return "Your record will be Inserted...";
	}
	

	public String updateData( int id,AddressClass add) {
		
		Session session=factory.openSession();
		session.beginTransaction();
		AddressClass ad= session.get(AddressClass.class,id);
		ad.setArea(add.getArea());
		ad.setCity(add.getCity());
		
		session.merge(ad);
		session.getTransaction().commit();
		session.close();
		return "Your record will be Updated...";
	}
	
     public String deleteData(int id) {
		
		Session session=factory.openSession();
		session.beginTransaction();
		AddressClass a=	session.get(AddressClass.class,id);
		session.remove(a);
		session.getTransaction().commit();
		session.close();
		return "Your record will be Deleted...";
	}
   public AddressClass getPerticularRecordData(int id) {
	
		Session session=factory.openSession();
		session.beginTransaction();
		String hqlQuery="from AddressClass where id=:myid";
		Query<AddressClass> query= session.createQuery(hqlQuery,AddressClass.class);
		query.setParameter("myid",id);
		AddressClass a= query.uniqueResult();
		session.getTransaction().commit();
		session.close();
		return a;
	}

   public List<AddressClass> getAllRecord() {
		Session session=factory.openSession();
		session.beginTransaction();
	
		String hqlQuery="from AddressClass";
		Query<AddressClass> query= session.createQuery(hqlQuery,AddressClass.class);
		List<AddressClass> list= query.list();
   return list;
   }
	
}
