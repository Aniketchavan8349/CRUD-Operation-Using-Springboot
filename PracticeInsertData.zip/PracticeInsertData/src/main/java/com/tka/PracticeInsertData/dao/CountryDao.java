package com.tka.PracticeInsertData.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tka.PracticeInsertData.entity.CountryClass;





@Repository
public class CountryDao {
	
	@Autowired
     SessionFactory factory;
	
	public String insertData(CountryClass c) {

		Session session=factory.openSession();
		session.beginTransaction();
		session.persist(c);
		session.getTransaction().commit();
		session.close();
		
		return "Data will be inserted";
		
	}
	public String updateData(int id,CountryClass c) {

		Session session=factory.openSession();
		session.beginTransaction();
	
		CountryClass con=session.get(CountryClass.class,id);
		
		con.setCid(c.getCid());
		con.setCname(c.getCname());
		session.merge(con);

		
		session.getTransaction().commit();
		session.close();
		
		return "Data will be updated";
		
	}
	
	public String deleteData(int id) {

		Session session=factory.openSession();
		session.beginTransaction();
		CountryClass c=	session.get(CountryClass.class, id);
		session.remove(c);
		session.getTransaction().commit();
		session.close();
		
		return "Data will be deleted";
		
	}

	public CountryClass getPerticularRecord(int id) {

		Session session=factory.openSession();
		session.beginTransaction();
		String hqlQuery="from CountryClass where id=:myid";
		Query<CountryClass> query= session.createQuery(hqlQuery,CountryClass.class);
		query.setParameter("myid",id);
		CountryClass c= query.uniqueResult();
		session.getTransaction().commit();
		session.close();
		
		return c;
		
	}

	public List<CountryClass> getAllRecord() {

		Session session=factory.openSession();
		session.beginTransaction();
		String hqlQuery="from CountryClass";
		Query<CountryClass> query= session.createQuery(hqlQuery,CountryClass.class);
	
		List<CountryClass> list= query.list();
		
		session.getTransaction().commit();
		session.close();
		
		return list;
		
	}

}
