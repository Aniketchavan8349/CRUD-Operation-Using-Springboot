package com.tka.PracticeInsertData.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.PracticeInsertData.dao.DaoClass;
import com.tka.PracticeInsertData.entity.Employee1;

@Service
public class ServiceClass {
	
	@Autowired
	DaoClass dao;
	
	public String InsertData(Employee1 e) {
		
		String msg=dao.insertData(e);
		return msg;
	}
	
	public String UpdateData(int id,Employee1 e) {
		String s=dao.updateData(id, e);
		return s;
		
	}

	public String DeleteData(int id) {
		String s=dao.deleteData(id);
		return s;
		
	}

	public Employee1 getPerticularRecord(int id) {
		Employee1 s=dao.getPerticularRecord(id);
		return s;
		
	}
	public List<Employee1> getAllRecord() {
		List<Employee1> s=dao.getAllRecord();
		return s;
		
	}

}
