package com.tka.PracticeInsertData.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tka.PracticeInsertData.entity.Employee1;
import com.tka.PracticeInsertData.service.ServiceClass;

@RestController
@RequestMapping("/apiemp")
public class ControllerClass {
	
	@Autowired
	ServiceClass service;
	
	@PostMapping("/saveData")
	public String saverecord( @RequestBody Employee1 e) {
		
		String msg=service.InsertData(e);
		
		return msg;
	}
	
	@PutMapping("updateData/{id}")
	public String updatedata(@PathVariable int id,@RequestBody Employee1 e) {
		
		String s=service.UpdateData(id, e);
		return s;
	}

	@DeleteMapping("deleteData/{id}")
	public String deleteData(@PathVariable int id) {
		
		String s=service.DeleteData(id);
		return s;
	}
	
	@GetMapping("getPerticularRecord/{id}")
	public Employee1 getPerticularRecordData(@PathVariable int id) {
		
		Employee1 s=service.getPerticularRecord(id);
		return s;
	}

	@GetMapping("getAllRecord")
	public List<Employee1> getAllRecord() {
		
		List<Employee1> s=service.getAllRecord();
		return s;
	}
	
}
