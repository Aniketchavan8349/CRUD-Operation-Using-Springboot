package com.tka.PracticeInsertData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticeInsertDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
